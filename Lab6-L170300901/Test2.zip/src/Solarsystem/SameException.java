package Solarsystem;

class SameException extends Exception {

	public SameException() {
		super("It's a planet that already exists." + "\n");
		
	}
}
