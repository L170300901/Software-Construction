package Atomicsystem;

class SameException extends Exception {

  public SameException() {
    super("It's a element that already exists." + "\n");

  }
}
