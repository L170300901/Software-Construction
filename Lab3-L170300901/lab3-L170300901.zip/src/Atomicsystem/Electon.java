package Atomicsystem;

public class Electon {
      
	public boolean onTrack = false;
	public int numberthoforbit;
	
}
