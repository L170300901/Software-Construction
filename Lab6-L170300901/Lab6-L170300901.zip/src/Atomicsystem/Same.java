package Atomicsystem;

public class Same extends Exception {

}
