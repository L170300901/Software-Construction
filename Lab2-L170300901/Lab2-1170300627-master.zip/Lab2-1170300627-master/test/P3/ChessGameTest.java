package P3;
import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertFalse;

import java.io.IOException;

import org.junit.Test;

public class ChessGameTest {

	
	@Test
    public void chesseatTest() throws IOException
    {
		chessinit.function();
        chess.function("1,1,3,4");
        chess.function("7,7,3,4");
        chess.function("0,0,3,4");
        chess.function("7,6,3,4");
        chess.function("0,1,3,4");
        chess.function("6,6,3,4");
        assertEquals("û��", getchessdata.function().get(3*8+3));
    }
	@Test
	public void chesswrongputTest() throws IOException
    {
		chessinit.function();
        chess.function("1,1,0,0");
        assertEquals("�ڳ�", getchessdata.function().get(0));
        assertEquals("�ڱ�", getchessdata.function().get(1*8 + 1));
    }
	@Test
    public void goeatTest() throws IOException
    {
		goinit.function();
		go.function("1,1");
        go.function("2,2");
        go.function("2,2");
        assertEquals("û��", getgodata.function().get(2*18+2));
    }
	@Test
	public void gowrongputTest() throws IOException
    {
		goinit.function();
        go.function("1,1");
        go.function("10,10");
        go.function("1,1");
        assertEquals("����", getgodata.function().get(1*18 + 1));
    }
}
