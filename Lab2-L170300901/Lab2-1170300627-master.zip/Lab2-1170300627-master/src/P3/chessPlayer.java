package P3;
import java.util.Scanner;

public class chessPlayer implements Player{

    public void getname() {
        Scanner sc = new Scanner(System.in);
        System.out.println("hello!chessplayer1,whats your name?");
        String name1 = sc.nextLine();
        System.out.println("hello!chessplayer1,whats your name?");
        String name2 = sc.nextLine();
    }
}